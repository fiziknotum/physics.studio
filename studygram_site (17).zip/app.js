/* Studygram: ünite sekmeleri + yönetici panelinden eklenen içerik */
(function () {
  var tabsBox = document.querySelector('.tabs');
  function slug(s) {
    var m = { 'ç': 'c', 'ğ': 'g', 'ı': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u', 'İ': 'i' };
    return String(s).toLowerCase().replace(/[çğıöşüİ]/g, function (c) { return m[c] || c; }).replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  }
  function units() { return [].slice.call(document.querySelectorAll('.unit')); }
  function tabs() { return [].slice.call(document.querySelectorAll('.tab')); }
  var current = 'all', finderOff = false;
  function norm(s) { return String(s || '').toLocaleLowerCase('tr').replace(/ı/g, 'i').normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
  function kindOn() { var b = document.querySelector('.kind.on'); return b ? b.getAttribute('data-k') : 'all'; }
  function cardMatches(card, words, kind) {
    if (kind !== 'all') {
      var has = false; [].forEach.call(card.querySelectorAll('.btn'), function (b) { var t = b.textContent.trim(); if ((kind === 'sim' && t === 'Simülasyon') || (kind === 'vid' && t === 'Video')) has = true; });
      if (!has) return false;
    }
    if (!words.length) return true;
    var sec = card.closest('.unit'), hay = norm(card.querySelector('h3').textContent + ' ' + (card.querySelector('.cbody p') || {}).textContent + ' ' + (sec ? sec.getAttribute('data-name') + ' ' + ((sec.querySelector('h2') || {}).firstChild || {}).nodeValue : ''));
    var toks = hay.split(/[^a-z0-9]+/).filter(Boolean);                       // sözcük başı eşleşmesi: “ayna”, “kaynama” içinde aranmaz
    return words.every(function (w) { return toks.some(function (t) { return t.indexOf(w) === 0; }); });
  }
  function toggleKinds() {
    var k = document.querySelector('.kinds'); if (!k) return;
    var hasVid = [].some.call(document.querySelectorAll('.card .btn'), function (b) { return b.textContent.trim() === 'Video'; });
    k.hidden = !hasVid; if (!hasVid) { [].forEach.call(document.querySelectorAll('.kind'), function (x) { x.classList.toggle('on', x.getAttribute('data-k') === 'all'); }); }
  }
  function refreshView() {
    var qi = document.getElementById('q'), words = (!finderOff && qi) ? norm(qi.value.trim()).split(/\s+/).filter(Boolean) : [], kind = finderOff ? 'all' : kindOn();
    var searching = words.length > 0, filtering = searching || kind !== 'all', total = 0;
    document.body.classList.toggle('filtering', filtering);
    units().forEach(function (s) {
      var vis = 0;
      [].forEach.call(s.querySelectorAll('.card'), function (c) { var ok = cardMatches(c, words, kind); c.hidden = !ok; if (ok) vis++; });
      total += (s.getAttribute('data-off') ? 0 : vis);
      var inTab = searching || current === 'all' || s.getAttribute('data-u') === current;
      s.hidden = !inTab || !!s.getAttribute('data-off') || !!s.getAttribute('data-empty') || (filtering && vis === 0);
    });
    var res = document.getElementById('result'), emp = document.getElementById('empty'), clr = document.getElementById('qclear');
    if (clr) clr.hidden = !(qi && qi.value);
    if (res) { res.hidden = !filtering; res.textContent = total + ' sonuç'; }
    if (emp) emp.hidden = !(filtering && total === 0);
    tabs().forEach(function (t) {
      var on = t.getAttribute('data-u') === (searching ? 'all' : current);
      t.classList.toggle('on', on); t.setAttribute('aria-selected', on);
      if (on) { try { t.parentNode.scrollTo({ left: t.offsetLeft - 20, behavior: 'smooth' }); } catch (e) {} }
    });
  }
  function show(u) {
    current = u;
    var qi = document.getElementById('q'); if (qi && qi.value) qi.value = '';
    refreshView();
    try { history.replaceState(null, '', u === 'all' ? location.pathname + location.search : '#' + u); } catch (e) {}
  }
  function bindTab(t) { t.addEventListener('click', function () { show(t.getAttribute('data-u')); }); }
  (function initFinder() {
    var qi = document.getElementById('q'), clr = document.getElementById('qclear');
    if (qi) { qi.addEventListener('input', refreshView); qi.addEventListener('keydown', function (e) { if (e.key === 'Escape') { qi.value = ''; refreshView(); } }); }
    if (clr) clr.addEventListener('click', function () { qi.value = ''; refreshView(); qi.focus(); });
    [].forEach.call(document.querySelectorAll('.kind'), function (b) { b.addEventListener('click', function () { [].forEach.call(document.querySelectorAll('.kind'), function (x) { x.classList.toggle('on', x === b); x.setAttribute('aria-pressed', x === b); }); refreshView(); }); });
    document.addEventListener('keydown', function (e) { if (e.key === '/' && qi && !/^(INPUT|TEXTAREA|SELECT)$/.test((document.activeElement || {}).tagName || '')) { e.preventDefault(); qi.focus(); } });
  })();
  tabs().forEach(bindTab);

  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function link(href, cls, text) { var a = el('a', cls, text); a.href = href; return a; }
  function ensureUnit(name) {
    var found = units().filter(function (s) { return s.getAttribute('data-name') === name; })[0];
    if (found) return found;
    var id = 'u-' + slug(name), sec = el('section', 'unit'), h = el('h2', null, name + ' '), sp = el('span', null, '0 konu'), grid = el('div', 'grid');
    sec.setAttribute('data-u', id); sec.setAttribute('data-name', name); h.appendChild(sp); sec.appendChild(h); sec.appendChild(grid);
    document.getElementById('konular').appendChild(sec);
    var t = el('button', 'tab', name); t.setAttribute('data-u', id); t.setAttribute('role', 'tab'); t.setAttribute('aria-selected', 'false');
    tabsBox.appendChild(t); bindTab(t);
    return sec;
  }
  function addCard(e) {
    var sec = ensureUnit(e.unit || 'Diğer'), grid = sec.querySelector('.grid');
    var main = e.sim ? 'izle.html?konu=' + encodeURIComponent(e.id) : (e.video || '#');
    var card = el('article', 'card'), th = link(main, 'thumb'); card.setAttribute('data-key', e.id);
    if (e.cover) { var im = el('img'); im.src = e.cover; im.alt = ''; im.loading = 'lazy'; th.appendChild(im); } else { th.classList.add('nocover'); th.appendChild(el('span', null, e.title)); }
    var b = el('div', 'cbody'); b.appendChild(el('h3', null, e.title)); b.appendChild(el('p', null, e.desc || ''));
    var btns = el('div', 'btns');
    if (e.sim) btns.appendChild(link(main, 'btn', 'Simülasyon'));
    if (e.video) btns.appendChild(link(e.video, e.sim ? 'btn alt' : 'btn', 'Video'));
    b.appendChild(btns); card.appendChild(th); card.appendChild(b);
    grid.insertBefore(card, grid.firstChild);
  }
  function applyHash() {
    var h = (location.hash || '').slice(1);
    if (h && units().some(function (s) { return s.getAttribute('data-u') === h; })) show(h);
  }
  applyHash();

  /* ---------- Site ayarları (icerik/ayarlar.json — yönetici panelinden) ---------- */
  function q(sel) { return document.querySelector(sel); }
  function luminance(hex) { var n = parseInt(hex.slice(1), 16), r = n >> 16, g = (n >> 8) & 255, b = n & 255; return (0.299 * r + 0.587 * g + 0.114 * b) / 255; }
  function lighten(hex, k) { var n = parseInt(hex.slice(1), 16), c = [n >> 16, (n >> 8) & 255, n & 255].map(function (v) { return Math.round(v + (255 - v) * k); }); return '#' + c.map(function (v) { return ('0' + v.toString(16)).slice(-2); }).join(''); }
  var dark = false; try { dark = window.matchMedia('(prefers-color-scheme: dark)').matches; } catch (e) {}
  function applySettings(S) {
    if (!S || typeof S !== 'object') return;
    var r = document.documentElement.style;
    if (S.kicker != null && q('.kicker')) { q('.kicker').textContent = S.kicker; q('.kicker').hidden = !S.kicker; }
    if (S.quote != null && q('.lead')) { q('.lead').textContent = S.quote; q('.lead').hidden = !S.quote; }
    var fl = q('footer .fline') || q('footer .wrap'); if (S.footer != null && fl) fl.textContent = S.footer;
    if (Array.isArray(S.features)) {
      var boxes = [].slice.call(document.querySelectorAll('.feat > div'));
      boxes.forEach(function (bx, i) {
        var f = S.features[i]; if (!f) return;
        bx.hidden = !!f.hidden;
        var oldBox = f.t === '🎬 15 saniyede konu';                                  // eski varsayılan: yeni metni koru
        if (!oldBox) { if (f.t != null) bx.querySelector('b').textContent = f.t; if (f.d != null) bx.querySelector('span').textContent = f.d; } else bx.hidden = false;
      });
      var feat = q('.feat'); if (feat) feat.hidden = boxes.every(function (b) { return b.hidden; });
    }
    if (S.social) ['tiktok', 'instagram', 'youtube'].forEach(function (p) {
      var a = q('.social a[data-p="' + p + '"]'); if (!a || S.social[p] == null) return;
      if (S.social[p]) { a.href = S.social[p]; a.hidden = false; } else a.hidden = true;
    });
    var th = S.theme || {};
    if (th.accent && /^#[0-9a-f]{6}$/i.test(th.accent)) {
      var ac = dark ? lighten(th.accent, 0.45) : th.accent;
      r.setProperty('--accent', ac); r.setProperty('--onaccent', luminance(ac) > 0.6 ? '#101318' : '#ffffff');
    }
    if (th.bg && /^#[0-9a-f]{6}$/i.test(th.bg) && !dark) { r.setProperty('--bg', th.bg); }
    if (th.wallpaper === false) document.body.style.backgroundImage = 'none';
    if (S.logo && q('img.logo')) q('img.logo').src = S.logo;
    // ünite adları, sırası, gizleme
    var un = S.unitNames || {}, hid = S.hiddenUnits || [];
    units().forEach(function (sec) {
      var orig = sec.getAttribute('data-name'), nm = un[orig];
      var h = sec.querySelector('h2'); if (nm && h && h.firstChild) h.firstChild.nodeValue = nm + ' ';
      var tb = tabs().filter(function (t) { return t.getAttribute('data-u') === sec.getAttribute('data-u'); })[0];
      if (tb && nm) tb.textContent = nm;
      var off = hid.indexOf(orig) >= 0; if (off) sec.setAttribute('data-off', '1'); else sec.removeAttribute('data-off'); if (tb) tb.hidden = off;
    });
    if (Array.isArray(S.unitOrder)) {
      var box = document.getElementById('konular'), ordered = S.unitOrder;
      var idx = function (n) { var i = ordered.indexOf(n); return i < 0 ? 999 : i; };
      units().sort(function (a, b) { return idx(a.getAttribute('data-name')) - idx(b.getAttribute('data-name')); }).forEach(function (sec) { box.appendChild(sec); });
      var tb2 = tabs().filter(function (t) { return t.getAttribute('data-u') !== 'all'; });
      tb2.sort(function (a, b) {
        var na = (units().filter(function (u) { return u.getAttribute('data-u') === a.getAttribute('data-u'); })[0] || a).getAttribute('data-name');
        var nb = (units().filter(function (u) { return u.getAttribute('data-u') === b.getAttribute('data-u'); })[0] || b).getAttribute('data-name');
        return idx(na) - idx(nb);
      }).forEach(function (t) { tabsBox.appendChild(t); });
    }
    // kartlar: başlık/açıklama, gizleme, ünite, sıra
    if (S.showStats === false && q('#stats')) q('#stats').hidden = true;
    if (S.showSearch === false && q('.finder')) { q('.finder').hidden = true; finderOff = true; }
    if (S.soon && q('#yakinda')) {
      var sc = q('#yakinda'); sc.hidden = !!S.soon.hidden;
      if (S.soon.title != null && sc.querySelector('h2')) sc.querySelector('h2').textContent = S.soon.title;
      [].slice.call(sc.querySelectorAll('.soon-item')).forEach(function (it, i) {
        var f = (S.soon.items || [])[i]; if (!f) return;
        it.hidden = !!f.hidden; if (f.t != null) it.querySelector('b').textContent = f.t; if (f.d != null) it.querySelector('span:last-child').textContent = f.d;
      });
    }
    var cs = S.cards || {};
    [].slice.call(document.querySelectorAll('.card')).forEach(function (card) {
      var c = cs[card.getAttribute('data-key')]; if (!c) return;
      if (c.title != null && c.title !== '') card.querySelector('h3').textContent = c.title;
      if (c.desc != null) card.querySelector('.cbody p').textContent = c.desc;
      if (c.hidden) { card.remove(); return; }
      if (c.unit) { var tgt = units().filter(function (u) { return u.getAttribute('data-name') === c.unit; })[0]; if (tgt) tgt.querySelector('.grid').appendChild(card); }
    });
    units().forEach(function (sec) {
      var g = sec.querySelector('.grid'), arr = [].slice.call(g.children);
      var ord = function (c) { var v = cs[c.getAttribute('data-key')]; return v && typeof v.order === 'number' ? v.order : 9999; };
      arr.map(function (c, i) { return { c: c, i: i }; }).sort(function (x, y) { return (ord(x.c) - ord(y.c)) || (x.i - y.i); }).forEach(function (o) { g.appendChild(o.c); });
    });
  }
  function updateStats() {
    var st = q('#stats'); if (!st) return;
    var cards = []; units().forEach(function (u) { if (!u.getAttribute('data-off')) cards = cards.concat([].slice.call(u.querySelectorAll('.card'))); });
    var sim = 0, vid = 0;
    cards.forEach(function (c) { [].forEach.call(c.querySelectorAll('.btn'), function (b) { var t = b.textContent.trim(); if (t === 'Simülasyon') sim++; else if (t === 'Video') vid++; }); });
    st.textContent = cards.length + ' konu · ' + sim + ' simülasyon' + (vid ? ' · ' + vid + ' video' : '');
  }
  function recount() {
    units().forEach(function (s) {
      var n = s.querySelectorAll('.card').length, sp = s.querySelector('h2 span'); if (sp) sp.textContent = n + ' konu';
      if (!n || s.getAttribute('data-off')) { s.setAttribute('data-empty', '1'); s.hidden = true; var tb = tabs().filter(function (t) { return t.getAttribute('data-u') === s.getAttribute('data-u'); })[0]; if (tb) tb.hidden = true; }
    });
  }
  function getJson(u, d) { return fetch(u + '?v=' + Date.now()).then(function (r) { return r.ok ? r.json() : d; }).catch(function () { return d; }); }
  Promise.all([getJson('icerik/konular.json', []), getJson('icerik/ayarlar.json', null)]).then(function (res) {
    var list = res[0], S = res[1];
    if (Array.isArray(list)) list.forEach(addCard);
    applySettings(S); recount(); updateStats(); toggleKinds(); applyHash(); refreshView();
  }).then(function () { document.documentElement.className = ''; }, function () { document.documentElement.className = ''; });

  try {   // yalnız yönetici (bu tarayıcıda panele bağlanmış kişi) görür
    if (localStorage.getItem('ps_admin_token')) { var f = link('admin.html', 'admin-fab', '⚙ Yönetici'); document.body.appendChild(f); }
  } catch (e) {}
})();
