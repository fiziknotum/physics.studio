# Otomatik haber güncelleme

- `kaynaklar.json`: haber kaynakları (RSS/Atom). `aktif` ile aç/kapat, `anahtar` ile kelime süzgeci, `max` ile kaynak başına haber sayısı.
- `.github/workflows/haberler.yml`: her gün otomatik çalışır (Actions sekmesinden "Run workflow" ile elle de çalışır) ve `icerik/haberler.json` dosyasını günceller.
- Elle haber eklemek için `icerik/haberler.json` içine şu biçimde kayıt ekle (`manuel: true` olanlar otomatik silinmez):
  `{"id":"m1","date":"2026-11-20","tag":"SINAV","title":"Başlık","text":"Kısa özet","url":"https://...","source":"Kaynak","manuel":true}`
- Etiketler: YENİ, SİTE, SINAV, FİZİK.
- Duyurular `icerik/duyurular.json` dosyasındadır (aynı biçim, url isteğe bağlı).
