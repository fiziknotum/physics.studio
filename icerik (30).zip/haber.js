(function(){
var TAGC={"YENİ":"t-yeni","SİTE":"t-site","SINAV":"t-sinav","FİZİK":"t-dunya"},AY=["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"];
function esc(t){return String(t==null?"":t).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}
function tar(s){var p=String(s).split("-");return p.length===3&&AY[+p[1]-1]?(+p[2])+" "+AY[+p[1]-1]+" "+p[0]:s}
function safe(u){return /^https?:\/\//i.test(u||"")?u:""}
function item(it){var m='<div class="hd-meta"><span class="hd-tag '+(TAGC[it.tag]||"t-site")+'">'+esc(it.tag)+'</span>'+esc(tar(it.date||""))+(it.source?" · "+esc(it.source):"")+"</div>";
 var b=m+"<b>"+esc(it.title)+"</b>"+(it.text?'<span class="d">'+esc(it.text)+"</span>":""),u=safe(it.url);
 return u?'<a class="hd-item" href="'+esc(u)+'" target="_blank" rel="noopener nofollow">'+b+"</a>":'<div class="hd-item">'+b+"</div>"}
[].forEach.call(document.querySelectorAll("[data-hd]"),function(box){
 var f=box.getAttribute("data-hd"),lim=+box.getAttribute("data-limit")||0,emp=box.getAttribute("data-empty")||"";
 var x=new XMLHttpRequest();x.open("GET","icerik/"+f+".json?v="+Date.now());x.onload=function(){try{if(x.status!==200)return;var a=JSON.parse(x.responseText);if(!Array.isArray(a))return;
  a.sort(function(p,q){return String(q.date).localeCompare(String(p.date))});if(lim)a=a.slice(0,lim);box.innerHTML=a.length?a.map(item).join(""):'<p class="hd-empty">'+esc(emp)+"</p>"}catch(e){}};x.send()});
})();