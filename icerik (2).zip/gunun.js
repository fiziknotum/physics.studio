(function () {
  var box = document.getElementById('gunun'); if (!box) return;
  function init() {
    var KEY = 'ps-ilerleme', L = 'ABCDE';
    function loadP() { try { var j = JSON.parse(localStorage.getItem(KEY) || 'null'); if (j && j.v === 1) return j; } catch (e) {} return { v: 1, topics: {}, tests: [], wrong: {}, daily: { streak: 0, last: '', days: {} } }; }
    function saveP(p) { try { localStorage.setItem(KEY, JSON.stringify(p)); } catch (e) {} }
    function two(n) { return ('0' + n).slice(-2); }
    function ymd(d) { return d.getFullYear() + '-' + two(d.getMonth() + 1) + '-' + two(d.getDate()); }
    var now = new Date(), today = ymd(now), dayNo = Math.floor(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 864e5);
    function get(u, cb) { var x = new XMLHttpRequest(); x.open('GET', u + '?v=' + (window.PS_V || '')); x.onload = function () { try { cb(JSON.parse(x.responseText)); } catch (e) {} }; x.send(); }
    function streakNow(p) { var y = new Date(now.getTime() - 864e5); return (p.daily.last === today || p.daily.last === ymd(y)) ? p.daily.streak : 0; }
    var mjTok = 0;
    function mjLoad(el) {
      var my = ++mjTok; el.style.visibility = 'hidden'; var done = false; function show() { if (!done && my === mjTok) { done = true; el.style.visibility = ''; } } setTimeout(show, 5000);
      function run() { MathJax.startup.promise.then(function () { return MathJax.typesetPromise([el]); }).then(show, show); }
      if (window.MathJax && MathJax.typesetPromise) return run();
      if (!document.getElementById('mj-s')) { window.MathJax = { tex: { inlineMath: [['$', '$'], ['\\(', '\\)']] }, options: { skipHtmlTags: ['script', 'noscript', 'style', 'textarea', 'pre'] } }; var s = document.createElement('script'); s.id = 'mj-s'; s.async = true; s.src = 'https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-chtml.js'; s.onload = run; s.onerror = show; document.head.appendChild(s); } else setTimeout(function () { mjLoad(el); }, 400);
    }
    get('sb/gunluk.json', function (list) {
      var pair = list[dayNo % list.length];
      get('sb/' + pair[0] + '.json', function (sh) {
        var q = sh.q[pair[1] - 1], p = loadP(), st = p.daily.days[today];
        function render() {
          var str = streakNow(loadP());
          var opts = q.o.map(function (o, j) { var c = ''; if (st) c = j === q.a ? ' ok' : (j === st.s ? ' no' : ''); return '<button type="button" class="qopt' + c + '" data-i="' + j + '"' + (st ? ' disabled' : '') + '><b>' + L[j] + '</b><span>' + o + '</span></button>'; }).join('');
          box.innerHTML = '<div class="gun-h"><span class="gun-t">Günün sorusu</span><span class="gun-k">' + sh.n + '</span><span class="gun-s">🔥 ' + str + ' günlük seri</span></div><div class="qtext">' + q.q + '</div>' + (q.f ? '<figure class="qfig">' + q.f + '</figure>' : '') + '<div class="qopts">' + opts + '</div><div class="qres ' + (st ? (st.g ? 'good' : 'bad') : '') + '"' + (st ? '' : ' hidden') + '>' + (st ? (st.g ? '✓ Doğru cevap!' : '✗ Yanlış. Doğru cevap: ' + L[q.a] + ' şıkkı.') : '') + '</div>'
            + '<div class="gun-f"><a class="gun-l" href="sorular/' + pair[0] + '.html#s' + pair[1] + '">' + (st ? 'Çözümü gör' : 'Konunun sorularına git') + ' →</a><a class="gun-l" href="test.html">Karışık test çöz →</a></div>';
          box.querySelectorAll('.qopt').forEach(function (b) { b.onclick = function () { ans(+b.dataset.i); }; });
          mjLoad(box);
        }
        function ans(s) {
          if (st) return; var p2 = loadP(), good = s === q.a; st = { s: s, g: good }; p2.daily.days[today] = st;
          var y = new Date(now.getTime() - 864e5); p2.daily.streak = (p2.daily.last === ymd(y)) ? p2.daily.streak + 1 : (p2.daily.last === today ? p2.daily.streak : 1); p2.daily.last = today;
          var t = p2.topics[pair[0]] || (p2.topics[pair[0]] = { c: 0, t: 0 }); t.t++; if (good) { t.c++; delete p2.wrong[pair[0] + '#' + pair[1]]; } else p2.wrong[pair[0] + '#' + pair[1]] = Date.now();
          var keys = Object.keys(p2.daily.days).sort(); if (keys.length > 60) keys.slice(0, keys.length - 60).forEach(function (k) { delete p2.daily.days[k]; });
          saveP(p2); render();
        }
        render();
      });
    });
  }
  if (document.readyState === 'complete') setTimeout(init, 300); else window.addEventListener('load', function () { setTimeout(init, 300); });
})();
