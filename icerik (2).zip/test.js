(function () {
  var R = document.getElementById('tapp'); if (!R) return;
  var KEY = 'ps-ilerleme', DATA = null, LABELS = {}, UNITS = [], POOL = [], CUR = null;
  function loadP() { try { var j = JSON.parse(localStorage.getItem(KEY) || 'null'); if (j && j.v === 1) return j; } catch (e) {} return { v: 1, topics: {}, tests: [], wrong: {}, daily: { streak: 0, last: '', days: {} } }; }
  function saveP(p) { try { localStorage.setItem(KEY, JSON.stringify(p)); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function mj(el, n) { n = n || 0; if (window.MathJax && MathJax.typesetPromise) { try { MathJax.typesetPromise([el]).catch(function () {}); } catch (e) {} } else if (n < 40) setTimeout(function () { mj(el, n + 1); }, 300); }
  function shuffle(a) { for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  var L = 'ABCDE';
  var sel = { units: {}, n: 10, mode: 'karisik' };

  function rate(p, k) { var t = p.topics[k]; return t && t.t ? t.c / t.t : null; }
  function setup() {
    var p = loadP(), nWrong = Object.keys(p.wrong).length, tot = 0, cor = 0;
    Object.keys(p.topics).forEach(function (k) { tot += p.topics[k].t; cor += p.topics[k].c; });
    var chips = UNITS.map(function (u) { return '<button type="button" class="tst-chip' + (sel.units[u.k] ? ' on' : '') + '" data-u="' + u.k + '" aria-pressed="' + (!!sel.units[u.k]) + '">' + esc(u.n) + ' <small>' + u.t.length + ' konu</small></button>'; }).join('');
    var cnt = [10, 20, 30].map(function (n) { return '<button type="button" class="tst-chip' + (sel.n === n ? ' on' : '') + '" data-n="' + n + '">' + n + ' soru</button>'; }).join('');
    var modes = [['karisik', 'Karışık'], ['zayif', 'Zayıf konularım'], ['yanlis', 'Yanlışlarım (' + nWrong + ')']].map(function (m) { var dis = (m[0] === 'yanlis' && !nWrong) || (m[0] === 'zayif' && tot < 5); return '<button type="button" class="tst-chip' + (sel.mode === m[0] ? ' on' : '') + '"' + (dis ? ' disabled' : '') + ' data-m="' + m[0] + '">' + m[1] + '</button>'; }).join('');
    R.innerHTML = '<div class="tst-card"><h2>Test ayarları</h2><h3>Üniteler</h3><div class="tst-row">' + chips + '</div><div class="tst-row"><button type="button" class="tst-link" id="tAll">Hepsini seç</button><button type="button" class="tst-link" id="tNone">Temizle</button></div>'
      + '<h3>Soru sayısı</h3><div class="tst-row">' + cnt + '</div><h3>Soru türü</h3><div class="tst-row">' + modes + '</div><p class="tst-hint">“Zayıf konularım” en çok yanlış yaptığın konulardan, “Yanlışlarım” daha önce yanlış cevapladığın sorulardan seçer. Bunlar için önce birkaç soru çözmen gerekir.</p>'
      + '<button type="button" class="pbtn" id="tGo">Testi başlat</button></div>' + statsHtml(p, tot, cor);
    R.querySelectorAll('[data-u]').forEach(function (b) { b.onclick = function () { sel.units[b.dataset.u] = !sel.units[b.dataset.u]; setup(); }; });
    R.querySelectorAll('[data-n]').forEach(function (b) { b.onclick = function () { sel.n = +b.dataset.n; setup(); }; });
    R.querySelectorAll('[data-m]').forEach(function (b) { b.onclick = function () { sel.mode = b.dataset.m; setup(); }; });
    document.getElementById('tAll').onclick = function () { UNITS.forEach(function (u) { sel.units[u.k] = true; }); setup(); };
    document.getElementById('tNone').onclick = function () { sel.units = {}; setup(); };
    document.getElementById('tGo').onclick = start;
    var rs = document.getElementById('tReset'); if (rs) rs.onclick = function () { if (confirm('Tüm ilerleme bilgisi bu tarayıcıdan silinsin mi?')) { try { localStorage.removeItem(KEY); } catch (e) {} setup(); } };
  }
  function statsHtml(p, tot, cor) {
    if (!tot) return '<div class="tst-card"><h2>İstatistiklerim</h2><p class="tst-hint">Henüz soru çözmedin. Test çözdükçe ya da konu sayfalarındaki soruları cevapladıkça burada ilerlemeni göreceksin. Bilgiler yalnızca bu tarayıcıda saklanır.</p></div>';
    var rows = UNITS.map(function (u) { var t = 0, c = 0; u.t.forEach(function (k) { var x = p.topics[k]; if (x) { t += x.t; c += x.c; } }); return { n: u.n, t: t, c: c }; }).filter(function (r) { return r.t; });
    var bars = rows.map(function (r) { var pc = Math.round(100 * r.c / r.t); return '<div class="tst-bar"><span>' + esc(r.n) + '</span><div><i style="width:' + pc + '%"></i></div><b>%' + pc + '</b><small>' + r.c + '/' + r.t + '</small></div>'; }).join('');
    var weak = Object.keys(p.topics).filter(function (k) { return p.topics[k].t >= 3 && LABELS[k]; }).sort(function (a, b) { return rate(p, a) - rate(p, b); }).slice(0, 5);
    var wk = weak.length ? '<h3>Üzerinde çalışabileceğin konular</h3><ul class="tst-weak">' + weak.map(function (k) { return '<li><a href="konu/' + k + '.html">' + esc(LABELS[k]) + '</a> <small>%' + Math.round(100 * rate(p, k)) + ' doğru (' + p.topics[k].c + '/' + p.topics[k].t + ')</small></li>'; }).join('') + '</ul>' : '';
    var last = p.tests.slice(-5).reverse().map(function (t) { return '<li>' + esc(t.d) + ': <b>' + t.c + '/' + t.n + '</b></li>'; }).join('');
    return '<div class="tst-card"><h2>İstatistiklerim</h2><div class="tst-big"><div><b>' + tot + '</b><span>çözülen soru</span></div><div><b>%' + Math.round(100 * cor / tot) + '</b><span>doğru oranı</span></div><div><b>' + p.daily.streak + '</b><span>günlük seri</span></div></div><h3>Ünitelere göre</h3>' + bars + wk + (last ? '<h3>Son testler</h3><ul class="tst-last">' + last + '</ul>' : '') + '<p class="tst-hint">Bu bilgiler yalnızca senin tarayıcında saklanır, kimseyle paylaşılmaz.</p><button type="button" class="tst-link" id="tReset">İlerlememi sıfırla</button></div>';
  }
  function start() {
    var p = loadP(), us = Object.keys(sel.units).filter(function (k) { return sel.units[k]; });
    if (!us.length) { alert('En az bir ünite seç.'); return; }
    var keys = {}; UNITS.forEach(function (u) { if (sel.units[u.k]) u.t.forEach(function (k) { keys[k] = 1; }); });
    var pool = POOL.filter(function (q) { return keys[q.k]; });
    if (sel.mode === 'yanlis') pool = pool.filter(function (q) { return p.wrong[q.k + '#' + q.i]; });
    var picked;
    if (sel.mode === 'zayif') {
      var w = {}; Object.keys(keys).forEach(function (k) { var r = rate(p, k); w[k] = r == null ? 0.5 : (1 - r) + 0.05; });
      pool = shuffle(pool.slice()); pool.sort(function (a, b) { return (w[b.k] * Math.random()) - (w[a.k] * Math.random()); }); picked = pool.slice(0, sel.n);
    } else picked = shuffle(pool.slice()).slice(0, sel.n);
    if (!picked.length) { alert('Bu seçimle soru bulunamadı. Ünite ya da soru türünü değiştir.'); return; }
    CUR = { qs: shuffle(picked), i: 0, c: 0, ans: [] }; show();
  }
  function show() {
    var q = CUR.qs[CUR.i], n = CUR.qs.length, pc = Math.round(100 * CUR.i / n);
    var opts = q.o.map(function (o, j) { return '<button type="button" class="qopt" data-i="' + j + '"><b>' + L[j] + '</b><span>' + o + '</span></button>'; }).join('');
    R.innerHTML = '<div class="tst-top"><span>Soru ' + (CUR.i + 1) + ' / ' + n + '</span><span class="tst-sc">Doğru: ' + CUR.c + '</span><button type="button" class="tst-link" id="tQuit">Çık</button></div><div class="tst-prog"><i style="width:' + pc + '%"></i></div>'
      + '<article class="qcard tst-q" data-k="' + esc(q.k) + '" data-i="' + q.i + '"><div class="qhead"><span class="qno">' + esc(LABELS[q.k]) + '</span><button type="button" class="qhint-btn" id="tHint" aria-label="İpucu göster" title="İpucu">?</button></div><div class="qtext">' + q.q + '</div>' + (q.f ? '<figure class="qfig">' + q.f + '</figure>' : '') + '<div class="qhint" id="tHintBox" hidden><b>İpucu:</b> ' + q.h + '</div><div class="qopts" role="group" aria-label="Şıklar">' + opts + '</div><div class="qres" id="tRes" hidden></div><div class="qsol" id="tSol" hidden><h4>Çözüm</h4><ol>' + q.s.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ol></div></article><div class="tst-next"><button type="button" class="pbtn" id="tNext" hidden>' + (CUR.i + 1 < n ? 'Sonraki soru →' : 'Sonucu gör') + '</button></div>';
    document.getElementById('tHint').onclick = function () { var b = document.getElementById('tHintBox'); b.hidden = !b.hidden; };
    document.getElementById('tQuit').onclick = function () { if (confirm('Testten çıkılsın mı? İlerleme kaydedilmez.')) setup(); };
    R.querySelectorAll('.qopt').forEach(function (b) { b.onclick = function () { answer(q, +b.dataset.i); }; });
    document.getElementById('tNext').onclick = function () { CUR.i++; if (CUR.i < CUR.qs.length) show(); else finish(); };
    mj(R); window.scrollTo({ top: 0 });
  }
  function answer(q, s) {
    var card = R.querySelector('.tst-q'); if (card.classList.contains('done')) return; card.classList.add('done');
    var good = s === q.a; if (good) CUR.c++; CUR.ans.push({ q: q, s: s, g: good });
    R.querySelectorAll('.qopt').forEach(function (o, j) { o.disabled = true; o.classList.add(j === q.a ? 'ok' : 'no'); if (j === s) o.classList.add('sel'); });
    var res = document.getElementById('tRes'); res.hidden = false; res.className = 'qres ' + (good ? 'good' : 'bad'); res.textContent = good ? '✓ Doğru cevap!' : '✗ Yanlış. Doğru cevap: ' + L[q.a] + ' şıkkı.';
    document.getElementById('tSol').hidden = false; document.getElementById('tNext').hidden = false; R.querySelector('.tst-sc').textContent = 'Doğru: ' + CUR.c;
    var p = loadP(); var t = p.topics[q.k] || (p.topics[q.k] = { c: 0, t: 0 }); t.t++; if (good) { t.c++; delete p.wrong[q.k + '#' + q.i]; } else p.wrong[q.k + '#' + q.i] = Date.now(); saveP(p); mj(R);
  }
  function finish() {
    var p = loadP(), n = CUR.qs.length, d = new Date(), ds = d.toLocaleDateString('tr-TR') + ' ' + d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
    p.tests.push({ d: ds, c: CUR.c, n: n }); p.tests = p.tests.slice(-20); saveP(p);
    var pc = Math.round(100 * CUR.c / n), by = {};
    CUR.ans.forEach(function (a) { var b = by[a.q.k] || (by[a.q.k] = { c: 0, t: 0 }); b.t++; if (a.g) b.c++; });
    var rows = Object.keys(by).map(function (k) { return '<li><a href="konu/' + k + '.html">' + esc(LABELS[k]) + '</a> <b>' + by[k].c + '/' + by[k].t + '</b></li>'; }).join('');
    var wr = CUR.ans.filter(function (a) { return !a.g; }).map(function (a) { return '<div class="tst-wrong"><small>' + esc(LABELS[a.q.k]) + '</small><div>' + a.q.q + '</div><p>Doğru cevap: <b>' + L[a.q.a] + '</b> — <span>' + a.q.o[a.q.a] + '</span> · <a href="sorular/' + a.q.k + '.html#s' + a.q.i + '">çözümü gör</a></p></div>'; }).join('');
    var msg = pc >= 80 ? 'Harika gidiyorsun!' : pc >= 50 ? 'İyi bir başlangıç, tekrarla pekişsin.' : 'Konu özetlerine göz atıp yeniden dene.';
    R.innerHTML = '<div class="tst-card tst-res"><h2>Test bitti</h2><div class="tst-score"><b>' + CUR.c + '</b> / ' + n + '<span>%' + pc + '</span></div><p>' + msg + '</p><h3>Konulara göre</h3><ul class="tst-last">' + rows + '</ul>' + (wr ? '<h3>Yanlış yaptıkların</h3>' + wr : '<p><b>Hiç yanlışın yok, tebrikler!</b></p>')
      + '<div class="tst-row"><button type="button" class="pbtn" id="tAgain">Yeni test</button>' + (wr ? '<button type="button" class="pbtn alt" id="tRetry">Yanlışları tekrar çöz</button>' : '') + '</div></div>';
    document.getElementById('tAgain').onclick = setup;
    var rt = document.getElementById('tRetry'); if (rt) rt.onclick = function () { var wq = CUR.ans.filter(function (a) { return !a.g; }).map(function (a) { return a.q; }); CUR = { qs: shuffle(wq), i: 0, c: 0, ans: [] }; show(); };
    mj(R); window.scrollTo({ top: 0 });
  }
  var x = new XMLHttpRequest(); x.open('GET', 'sb/hepsi.json?v=' + (window.PS_V || '')); x.onload = function () {
    try { DATA = JSON.parse(x.responseText); } catch (e) { R.innerHTML = '<p>Sorular yüklenemedi.</p>'; return; }
    LABELS = DATA.l; UNITS = DATA.u; POOL = DATA.q; UNITS.forEach(function (u) { sel.units[u.k] = true; }); setup();
  }; x.onerror = function () { R.innerHTML = '<p>Sorular yüklenemedi. İnternet bağlantını kontrol edip sayfayı yenile.</p>'; }; x.send();
})();
