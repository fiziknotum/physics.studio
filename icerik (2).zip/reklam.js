/* Reklam kutuları: icerik/reklam.json içinde "aktif": true ve reklam birimi kodu (slot) girilmedikçe hiçbir şey göstermez. */
(function () {
  var cs = document.currentScript, base = cs && cs.src ? cs.src.replace(/[^\/]*$/, '') : '';
  var boxes = [].slice.call(document.querySelectorAll('.adslot[data-ad]')); if (!boxes.length) return;
  var x = new XMLHttpRequest(); x.open('GET', base + 'icerik/reklam.json?v=' + Date.now());
  x.onload = function () {
    try {
      if (x.status !== 200) return; var c = JSON.parse(x.responseText); if (!c || !c.aktif || !/^ca-pub-\d+$/.test(c.client || '')) return;
      var st = document.createElement('style'); st.textContent = '.adslot{margin:26px auto;max-width:728px;min-height:100px;text-align:center;clear:both}.adslot small{display:block;font:600 10.5px system-ui,sans-serif;letter-spacing:.8px;color:#8a8576;text-transform:uppercase;margin:0 0 4px}.adslot ins{display:block}@media(max-width:600px){.adslot{min-height:250px}}'; document.head.appendChild(st);
      boxes.forEach(function (b) {
        var id = (c.slots && c.slots[b.getAttribute('data-ad')]) || c.slot; if (!/^\d+$/.test(String(id || ''))) return;
        b.innerHTML = '<small>Reklam</small><ins class="adsbygoogle" style="display:block" data-ad-client="' + c.client + '" data-ad-slot="' + id + '" data-ad-format="auto" data-full-width-responsive="true"></ins>'; b.hidden = false;
        try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) {}
      });
    } catch (e) {}
  }; x.send();
})();
