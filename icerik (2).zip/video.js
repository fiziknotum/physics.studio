/* Konu sayfalarında kısa video kartı: icerik/videolar.json'dan { "konu_anahtari": "YouTube adresi ya da kimliği" } okur.
   Video, kullanıcı oynat'a basana kadar YouTube'dan hiçbir şey yüklemez (hız + gizlilik). */
(function () {
  var BASE = (document.currentScript && document.currentScript.src || '').replace(/video\.js.*$/, '');
  var key = (location.pathname.match(/\/konu\/([^\/.]+)\.html$/) || [])[1]; if (!key) return;
  function idOf(v) { v = String(v || '').trim(); var m = v.match(/(?:shorts\/|youtu\.be\/|[?&]v=|embed\/)([A-Za-z0-9_-]{11})/); if (m) return m[1]; return /^[A-Za-z0-9_-]{11}$/.test(v) ? v : ''; }
  fetch(BASE + 'icerik/videolar.json?v=' + Date.now()).then(function (r) { return r.ok ? r.json() : {}; }).catch(function () { return {}; }).then(function (V) {
    var id = idOf((V || {})[key]); if (!id) return;
    var cta = document.querySelector('.cta-big'); if (!cta) return;
    var s = document.createElement('section'); s.className = 'kv';
    s.innerHTML = '<button type="button" class="kv-play" aria-label="Kısa videoyu oynat"><img loading="lazy" alt="" src="https://i.ytimg.com/vi/' + id + '/hqdefault.jpg"><span class="kv-btn" aria-hidden="true">▶</span><span class="kv-tag">kısa video</span></button>'
      + '<div class="kv-txt"><h2>Konuyu 15 saniyede izle</h2><p>Simülasyondan önce kısa bir bakış: olay, formül ve sonuç tek videoda.</p><a class="pbtn alt" href="https://www.youtube.com/shorts/' + id + '" target="_blank" rel="noopener">YouTube’da aç</a></div>';
    cta.parentNode.insertBefore(s, cta.nextSibling);
    s.querySelector('.kv-play').addEventListener('click', function () {
      var f = document.createElement('iframe'); f.src = 'https://www.youtube-nocookie.com/embed/' + id + '?autoplay=1&rel=0&playsinline=1'; f.title = 'Kısa video';
      f.allow = 'autoplay; encrypted-media; picture-in-picture'; f.allowFullscreen = true; this.replaceWith(f); f.className = 'kv-frame';
      try { window.psEv && psEv('video_oynat', { konu: key }); } catch (e) {}
    });
  });
})();
