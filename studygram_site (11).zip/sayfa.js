/* Alt sayfalar: yönetici panelindeki iletişim e-postası, "Hakkında" yazısı ve hesap bağlantıları */
(function () {
  function getJson(u) { return fetch(u + '?v=' + Date.now()).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; }); }
  function all(sel) { return [].slice.call(document.querySelectorAll(sel)); }
  getJson('icerik/ayarlar.json').then(function (S) {
    S = S || {};
    var email = (S.contact && S.contact.email || '').trim();
    all('[data-fill="email"]').forEach(function (a) { if (email) { a.textContent = email; a.href = 'mailto:' + email; } a.hidden = !email; });
    all('[data-only="email"]').forEach(function (e) { e.hidden = !email; });
    all('[data-only="noemail"]').forEach(function (e) { e.hidden = !!email; });
    var about = (S.about || '').trim(), ab = document.querySelector('[data-fill="about"]');
    if (about && ab) { ab.textContent = ''; about.split(/\n{2,}/).forEach(function (p) { var el = document.createElement('p'); el.textContent = p.replace(/\n/g, ' '); ab.appendChild(el); }); }
    all('[data-social]').forEach(function (a) { var v = S.social && S.social[a.getAttribute('data-social')]; if (v) a.href = v; if (S.social && S.social[a.getAttribute('data-social')] === '') a.hidden = true; });
    var form = document.getElementById('cform');
    if (form && email) form.addEventListener('submit', function (e) {
      e.preventDefault();
      var f = new FormData(form), subj = '[Physics.Studio] ' + (f.get('konu') || 'Mesaj'), body = (f.get('mesaj') || '') + '\n\n— ' + (f.get('ad') || '');
      window.location.href = 'mailto:' + email + '?subject=' + encodeURIComponent(subj) + '&body=' + encodeURIComponent(body);
    });
    var fl = S.footer; if (fl != null) { var el = document.querySelector('.pfooter .fline'); if (el && fl) el.textContent = fl; }
  });
})();
