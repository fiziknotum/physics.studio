# Studygram Fizik

Etkileşimli fizik simülasyonları ve kısa videolar (@fizik_studygram).

- `index.html`: ana sayfa
- `izle.html?konu=<anahtar>`: simülasyonlar
- `videolar/`: 15 sn dikey videolar
